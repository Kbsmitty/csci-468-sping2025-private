package edu.montana.csci.csci468.demo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Scratch {

    static int foo = 10;

    int addThirteen(int i) {
        return i + 13;
    }

    public static void main(String[] args) {
        System.out.println("foo");
        System.out.println("bar");
    }
}
